

export type ResponseLogin = {
  success: boolean;
  message: string;
  token: string;
};

// export {IAuthReducer};